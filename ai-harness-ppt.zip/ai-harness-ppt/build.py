#!/usr/bin/env python3
"""拼装 PPT.html：base(引擎+样式) + parts/*.html（按文件名排序）"""
import glob, os, re
here = os.path.dirname(os.path.abspath(__file__))
base = open(os.path.join(here, 'deck-base.html'), encoding='utf-8').read()
parts = sorted(glob.glob(os.path.join(here, 'parts', 'slides-*.html')))
body = '\n'.join(open(p, encoding='utf-8').read() for p in parts)
marker = '<div id="stage"></div>'
assert base.count(marker) == 1, 'anchor not found'
out = base.replace(marker, marker + '\n' + body, 1)
# 自动注入 buildOverview()/fit() 启动
out = out.replace('window.addEventListener(\'resize\', fit);',
                  "window.addEventListener('resize', fit);\nbuildOverview();\nfit();\ngo(Math.max(0,(parseInt(location.hash.slice(1))||1)-1), false);")
open(os.path.join(here, 'PPT.html'), 'w', encoding='utf-8').write(out)
n = len(re.findall(r'<section class="slide"', out))
print(f'parts={len(parts)} slides={n} size={len(out)/1024:.0f}KB')
