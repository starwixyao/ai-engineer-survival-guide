#!/usr/bin/env python3
"""用法: python3 shot.py 3 5 10  → 渲染 PPT.html 的第 3/5/10 页为 PNG (1600x900)

为什么不用 #N 直接截图：Chrome 的 virtual-time 会让页面自身的 transition 停在
中间态，偶发得到 rgba(31,30,27) 的过渡底色或 opacity:0 的空帧。这里把目标页
直接写成 .active 并禁用过渡，保证每次渲染都是稳定的终态。
"""
import subprocess, sys, os
here = os.path.dirname(os.path.abspath(__file__))
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
outdir = os.path.join(here, 'shots'); os.makedirs(outdir, exist_ok=True)

FORCE = """
<style>
  *{transition:none!important;animation:none!important}
  .slide{opacity:0!important;visibility:hidden!important}
  .slide.active{opacity:1!important;visibility:visible!important;transform:none!important}
  #hud,#progress{display:none!important}
</style>
<script>
window.addEventListener('load', function(){
  var n = %d;
  document.querySelectorAll('.slide').forEach(function(s,i){
    s.classList.toggle('active', i === n-1);
    s.classList.remove('leaving');
  });
});
</script>
"""

for p in sys.argv[1:]:
    p = int(p)
    out = os.path.join(outdir, f"p{p:02d}.png")
    src = os.path.join(here, 'PPT.html')
    tmp = os.path.join('/tmp', f'deck_shot_{p}.html')
    html = open(src, encoding='utf-8').read().replace('</head>', FORCE % p + '</head>', 1)
    open(tmp, 'w', encoding='utf-8').write(html)
    subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--no-sandbox", "--hide-scrollbars",
                    "--virtual-time-budget=6000", "--window-size=1600,987",
                    f"--screenshot={out}", f"file://{tmp}"], capture_output=True)
    print(out)
